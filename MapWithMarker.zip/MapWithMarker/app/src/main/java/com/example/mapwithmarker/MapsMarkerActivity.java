package com.example.mapwithmarker;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * An activity that displays a Google map with a marker (pin) to indicate a particular location.
 */
public class MapsMarkerActivity extends AppCompatActivity
        implements OnMapReadyCallback{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        LatLng MBK = new LatLng(-8.084363, 112.176159);
        googleMap.addMarker(new MarkerOptions().position(MBK)
                .title("Makam Bung Karno"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(MBK));

        LatLng IG = new LatLng(-8.097890, 112.176297);
        googleMap.addMarker(new MarkerOptions().position(IG)
                .title("Istana Gebang"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(IG));

        LatLng Penataran = new LatLng(-8.016083, 112.209750);
        googleMap.addMarker(new MarkerOptions().position(Penataran)
                .title("Candi Penataran"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(Penataran));
    }
}
